"use client"

import { useMemo, useState } from "react"
import { WorkbenchHeader } from "./components/grantpilot/header"
import { ControlBar, type ViewId } from "./components/grantpilot/control-bar"
import { MatchMatrix } from "./components/grantpilot/match-matrix"
import { AwardFit } from "./components/grantpilot/award-fit"
import { ScoreHeatmap } from "./components/grantpilot/score-heatmap"
import { Deadlines } from "./components/grantpilot/deadlines"
import { SelectedPanel } from "./components/grantpilot/selected-panel"
import { RankedStrip } from "./components/grantpilot/ranked-strip"
import { GRANTS, DEFAULT_FILTERS, applyFilters, type Filters } from "./lib/grant-data"

export default function GrantPilotWorkbench() {
  const [view, setView] = useState<ViewId>("matrix")
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS)
  const [selectedId, setSelectedId] = useState<string | null>("gg-1")
  const [comparison, setComparison] = useState<Set<string>>(new Set())

  const filtered = useMemo(() => applyFilters(GRANTS, filters), [filters])
  const selectedGrant = GRANTS.find((g) => g.id === selectedId) ?? null

  const toggleComparison = (id: string) =>
    setComparison((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  const visualization = () => {
    const props = { grants: filtered, selectedId, onSelect: setSelectedId }
    switch (view) {
      case "matrix":
        return <MatchMatrix {...props} />
      case "award":
        return <AwardFit {...props} />
      case "heatmap":
        return <ScoreHeatmap {...props} />
      case "deadlines":
        return <Deadlines {...props} />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <WorkbenchHeader />
      <ControlBar view={view} onViewChange={setView} filters={filters} onFiltersChange={setFilters} />

      <main className="mx-auto max-w-[1600px] space-y-4 p-4 md:p-6">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[60fr_40fr] xl:grid-cols-[68fr_32fr]">
          <div key={view} className="animate-in fade-in-50 duration-300">
            {visualization()}
          </div>
          <div className="lg:sticky lg:top-[148px] lg:h-[calc(100vh-168px)]">
            <SelectedPanel
              grant={selectedGrant}
              inComparison={selectedGrant ? comparison.has(selectedGrant.id) : false}
              onToggleComparison={toggleComparison}
            />
          </div>
        </div>

        <RankedStrip
          grants={filtered}
          selectedId={selectedId}
          onSelect={setSelectedId}
          comparison={comparison}
          onToggleComparison={toggleComparison}
        />
      </main>
    </div>
  )
}
