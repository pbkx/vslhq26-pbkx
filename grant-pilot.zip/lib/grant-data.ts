export type GrantSource = "grants.gov" | "irs"
export type Eligibility = "eligible" | "verify" | "ineligible"

export type ScoreBreakdown = {
  mission: number
  eligibility: number
  geography: number
  awardFit: number
  historical: number
  deadline: number
}

export type Grant = {
  id: string
  title: string
  funder: string
  source: GrantSource
  matchScore: number
  confidence: number
  /** 0 (low) - 100 (high) estimated application effort */
  effort: number
  awardMin: number | null
  awardMax: number | null
  /** true when only a single historical award value is known */
  singleKnownAward?: boolean
  eligibility: Eligibility
  /** ISO date, or null when there is no confirmed application deadline */
  deadline: string | null
  description: string
  whyMatches: string
  eligibilityConcern: string
  geographicEvidence: string
  sourceDisclaimer: string
  scores: ScoreBreakdown
}

/** Reference "today" so the deadline timeline is deterministic for the mock. */
export const TODAY = new Date("2026-07-28T00:00:00Z")

function daysFromToday(days: number): string {
  const d = new Date(TODAY)
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}

export const GRANTS: Grant[] = [
  {
    id: "gg-1",
    title: "Community Economic Development Projects",
    funder: "U.S. Dept. of Health & Human Services (OCS)",
    source: "grants.gov",
    matchScore: 91,
    confidence: 84,
    effort: 68,
    awardMin: 200000,
    awardMax: 800000,
    eligibility: "eligible",
    deadline: daysFromToday(24),
    description:
      "Funds Community Development Corporations to create employment and business development opportunities for low-income individuals.",
    whyMatches:
      "Your workforce and small-business incubation programs align directly with OCS job-creation priorities in distressed communities.",
    eligibilityConcern: "Requires designation as a Community Development Corporation with active 501(c)(3) status.",
    geographicEvidence: "Program service area overlaps 3 HHS-designated distressed census tracts you already serve.",
    sourceDisclaimer: "Forecasted opportunity based on the FY26 OCS funding cycle on Grants.gov.",
    scores: { mission: 92, eligibility: 88, geography: 90, awardFit: 86, historical: 74, deadline: 82 },
  },
  {
    id: "gg-2",
    title: "Rural Community Facilities Technical Assistance",
    funder: "USDA Rural Development",
    source: "grants.gov",
    matchScore: 78,
    confidence: 71,
    effort: 45,
    awardMin: 50000,
    awardMax: 250000,
    eligibility: "verify",
    deadline: daysFromToday(63),
    description:
      "Supports technical assistance and training to help rural communities develop essential community facilities.",
    whyMatches: "Your capacity-building services for rural nonprofits map cleanly to the TA and training objectives.",
    eligibilityConcern: "Applicant must demonstrate a track record of serving communities under 20,000 population.",
    geographicEvidence: "Two of your four field offices sit within USDA-eligible rural zones.",
    sourceDisclaimer: "Current opportunity posted on Grants.gov; verify rural eligibility before applying.",
    scores: { mission: 80, eligibility: 62, geography: 72, awardFit: 70, historical: 58, deadline: 76 },
  },
  {
    id: "irs-1",
    title: "Community Health & Human Services Giving",
    funder: "The Hartwell Family Foundation",
    source: "irs",
    matchScore: 86,
    confidence: 62,
    effort: 30,
    awardMin: 75000,
    awardMax: 300000,
    eligibility: "eligible",
    deadline: null,
    description:
      "Private foundation with a multi-year pattern of grants to regional health and human-services nonprofits.",
    whyMatches: "990-PF filings show repeated six-figure gifts to organizations with a mission profile like yours.",
    eligibilityConcern: "No published guidelines; giving appears to be invitation-oriented in recent years.",
    geographicEvidence: "80% of disbursements went to nonprofits headquartered in your state.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 90, eligibility: 82, geography: 88, awardFit: 84, historical: 91, deadline: 20 },
  },
  {
    id: "irs-2",
    title: "Education & Youth Development Grants",
    funder: "Callahan Charitable Trust",
    source: "irs",
    matchScore: 82,
    confidence: 58,
    effort: 28,
    awardMin: 25000,
    awardMax: 150000,
    eligibility: "eligible",
    deadline: null,
    description: "Trust that consistently funds after-school, mentoring, and youth workforce readiness programs.",
    whyMatches: "Your youth apprenticeship pipeline matches the trust's documented education funding pattern.",
    eligibilityConcern: "Trust historically funds only organizations with prior programmatic partnerships.",
    geographicEvidence: "Recent 990-PF grants concentrated in your metro region.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 86, eligibility: 78, geography: 80, awardFit: 76, historical: 88, deadline: 18 },
  },
  {
    id: "irs-3",
    title: "Arts & Culture Program Support",
    funder: "Meridian Arts Foundation",
    source: "irs",
    matchScore: 61,
    confidence: 49,
    effort: 40,
    awardMin: 10000,
    awardMax: 60000,
    eligibility: "verify",
    deadline: null,
    description: "Foundation supporting community arts programming and cultural preservation initiatives.",
    whyMatches: "Your community arts residencies partially overlap the foundation's cultural funding history.",
    eligibilityConcern: "Mission alignment is partial; arts are a secondary program area for you.",
    geographicEvidence: "Mixed national giving with some in-region grants.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 58, eligibility: 60, geography: 55, awardFit: 62, historical: 64, deadline: 15 },
  },
  {
    id: "irs-4",
    title: "Housing & Homelessness Response",
    funder: "The Ellsworth Foundation",
    source: "irs",
    matchScore: 88,
    confidence: 66,
    effort: 35,
    awardMin: 100000,
    awardMax: 500000,
    eligibility: "eligible",
    deadline: null,
    description: "Large private foundation with sustained investment in supportive housing and homelessness prevention.",
    whyMatches: "Your rapid-rehousing outcomes fit the foundation's evidence-based housing priorities.",
    eligibilityConcern: "Competitive field; foundation favors coalitions over single applicants.",
    geographicEvidence: "Multiple grants to housing providers within 50 miles of your headquarters.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 92, eligibility: 80, geography: 86, awardFit: 90, historical: 84, deadline: 22 },
  },
  {
    id: "irs-5",
    title: "Food Security & Nutrition Grants",
    funder: "Braddock Community Fund",
    source: "irs",
    matchScore: 74,
    confidence: 55,
    effort: 26,
    awardMin: 40000,
    awardMax: null,
    singleKnownAward: true,
    eligibility: "eligible",
    deadline: null,
    description: "Community fund with a recurring pattern of food-bank and nutrition program support.",
    whyMatches: "Your mobile pantry program aligns with the fund's documented nutrition giving.",
    eligibilityConcern: "Only one historical award amount is documented, limiting range confidence.",
    geographicEvidence: "Grants concentrated in your county over the last three filings.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 78, eligibility: 74, geography: 82, awardFit: 60, historical: 70, deadline: 16 },
  },
  {
    id: "irs-6",
    title: "Workforce & Economic Mobility",
    funder: "The Voss Family Trust",
    source: "irs",
    matchScore: 79,
    confidence: 57,
    effort: 32,
    awardMin: 50000,
    awardMax: 200000,
    eligibility: "verify",
    deadline: null,
    description: "Trust funding workforce training, credentialing, and economic mobility programs.",
    whyMatches: "Your sector-based training model matches the trust's employment-focused giving.",
    eligibilityConcern: "Recent filings show a narrowing focus on healthcare-sector training only.",
    geographicEvidence: "Statewide giving with several in-region recipients.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 82, eligibility: 64, geography: 74, awardFit: 78, historical: 80, deadline: 17 },
  },
  {
    id: "irs-7",
    title: "Environmental Stewardship Fund",
    funder: "Greenridge Conservation Foundation",
    source: "irs",
    matchScore: 38,
    confidence: 44,
    effort: 55,
    awardMin: 20000,
    awardMax: 120000,
    eligibility: "ineligible",
    deadline: null,
    description: "Foundation dedicated to land conservation and environmental education.",
    whyMatches: "Minimal overlap; only your community garden program touches this funder's interests.",
    eligibilityConcern: "Your mission does not align with the foundation's conservation-only giving history.",
    geographicEvidence: "Giving concentrated outside your service region.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 34, eligibility: 30, geography: 40, awardFit: 58, historical: 42, deadline: 14 },
  },
  {
    id: "irs-8",
    title: "Health Equity & Access Initiative",
    funder: "The Calderon Foundation",
    source: "irs",
    matchScore: 84,
    confidence: 63,
    effort: 34,
    awardMin: 80000,
    awardMax: 350000,
    eligibility: "eligible",
    deadline: null,
    description: "Foundation investing in community health centers and health-access programs.",
    whyMatches: "Your mobile clinic outcomes fit the foundation's health-equity funding pattern.",
    eligibilityConcern: "Foundation prefers FQHC-affiliated applicants in recent cycles.",
    geographicEvidence: "Several recent grants to health providers in your metro area.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 88, eligibility: 76, geography: 84, awardFit: 82, historical: 86, deadline: 19 },
  },
  {
    id: "irs-9",
    title: "Senior Services & Aging Support",
    funder: "Ainsworth Legacy Fund",
    source: "irs",
    matchScore: 66,
    confidence: 51,
    effort: 29,
    awardMin: 15000,
    awardMax: 90000,
    eligibility: "verify",
    deadline: null,
    description: "Fund supporting senior centers, aging-in-place, and elder-care programs.",
    whyMatches: "Your senior nutrition and companionship programs partially match the fund's giving.",
    eligibilityConcern: "Historical grants skew toward direct-service senior centers.",
    geographicEvidence: "Regional giving with limited data on recipient locations.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 68, eligibility: 62, geography: 66, awardFit: 64, historical: 72, deadline: 15 },
  },
  {
    id: "irs-10",
    title: "Early Childhood & Family Support",
    funder: "The Pemberton Trust",
    source: "irs",
    matchScore: 80,
    confidence: 59,
    effort: 31,
    awardMin: 60000,
    awardMax: 240000,
    eligibility: "eligible",
    deadline: null,
    description: "Trust with a consistent record of early-childhood education and family stability grants.",
    whyMatches: "Your two-generation family program matches the trust's early-childhood priorities.",
    eligibilityConcern: "Trust favors licensed early-learning providers.",
    geographicEvidence: "Grants concentrated within your state over four filings.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 84, eligibility: 72, geography: 80, awardFit: 78, historical: 82, deadline: 18 },
  },
  {
    id: "irs-11",
    title: "Veterans Reintegration Programs",
    funder: "Halstead Veterans Foundation",
    source: "irs",
    matchScore: 57,
    confidence: 47,
    effort: 38,
    awardMin: 30000,
    awardMax: 130000,
    eligibility: "verify",
    deadline: null,
    description: "Foundation supporting veteran employment, housing, and reintegration services.",
    whyMatches: "Your veteran workforce track partially overlaps the foundation's funding history.",
    eligibilityConcern: "Foundation prioritizes veteran-led organizations.",
    geographicEvidence: "National giving with a few in-region recipients.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 60, eligibility: 52, geography: 54, awardFit: 66, historical: 62, deadline: 16 },
  },
  {
    id: "irs-12",
    title: "Digital Inclusion & Literacy",
    funder: "The Marlowe Fund",
    source: "irs",
    matchScore: 71,
    confidence: 53,
    effort: 27,
    awardMin: 25000,
    awardMax: 110000,
    eligibility: "eligible",
    deadline: null,
    description: "Fund supporting digital literacy, broadband access, and technology-equity programs.",
    whyMatches: "Your community tech lab and device-lending program fit the fund's digital-inclusion giving.",
    eligibilityConcern: "Limited history; only two documented grant cycles.",
    geographicEvidence: "Both prior grants went to organizations in your region.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 74, eligibility: 70, geography: 76, awardFit: 66, historical: 64, deadline: 17 },
  },
  {
    id: "irs-13",
    title: "Mental & Behavioral Health Support",
    funder: "Thornton Wellness Foundation",
    source: "irs",
    matchScore: 83,
    confidence: 61,
    effort: 36,
    awardMin: 90000,
    awardMax: 400000,
    eligibility: "eligible",
    deadline: null,
    description: "Foundation with sustained funding for community behavioral health and crisis services.",
    whyMatches: "Your peer-support and crisis-response programs fit the foundation's behavioral-health giving.",
    eligibilityConcern: "Foundation favors licensed behavioral-health providers.",
    geographicEvidence: "Multiple grants to providers within your service region.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 86, eligibility: 74, geography: 82, awardFit: 84, historical: 84, deadline: 19 },
  },
  {
    id: "irs-14",
    title: "Immigrant & Refugee Services",
    funder: "The Okonkwo Foundation",
    source: "irs",
    matchScore: 69,
    confidence: 52,
    effort: 33,
    awardMin: 35000,
    awardMax: 160000,
    eligibility: "verify",
    deadline: null,
    description: "Foundation funding immigrant integration, legal aid, and refugee resettlement support.",
    whyMatches: "Your newcomer workforce program overlaps the foundation's integration funding.",
    eligibilityConcern: "Foundation prefers organizations with in-house legal services.",
    geographicEvidence: "Grants distributed across gateway cities including your metro.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 72, eligibility: 60, geography: 70, awardFit: 68, historical: 74, deadline: 16 },
  },
  {
    id: "irs-15",
    title: "Small Business & Entrepreneurship",
    funder: "Redfield Opportunity Trust",
    source: "irs",
    matchScore: 76,
    confidence: 56,
    effort: 30,
    awardMin: 50000,
    awardMax: 220000,
    eligibility: "eligible",
    deadline: null,
    description: "Trust supporting microenterprise, small-business technical assistance, and entrepreneurship.",
    whyMatches: "Your small-business incubator aligns with the trust's documented economic-development giving.",
    eligibilityConcern: "Trust favors CDFI-affiliated applicants.",
    geographicEvidence: "Recent grants concentrated in your state's opportunity zones.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 80, eligibility: 72, geography: 78, awardFit: 76, historical: 78, deadline: 18 },
  },
  {
    id: "irs-16",
    title: "Disability Inclusion & Access",
    funder: "The Whitfield Access Foundation",
    source: "irs",
    matchScore: 63,
    confidence: 50,
    effort: 34,
    awardMin: 20000,
    awardMax: 100000,
    eligibility: "verify",
    deadline: null,
    description: "Foundation funding disability services, accessibility, and inclusive employment programs.",
    whyMatches: "Your supported-employment program partially matches the foundation's inclusion giving.",
    eligibilityConcern: "Historical focus on direct-service disability providers.",
    geographicEvidence: "Mixed national and regional giving.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 66, eligibility: 58, geography: 60, awardFit: 64, historical: 68, deadline: 15 },
  },
  {
    id: "irs-17",
    title: "Community Safety & Violence Prevention",
    funder: "Larkspur Community Foundation",
    source: "irs",
    matchScore: 72,
    confidence: 54,
    effort: 37,
    awardMin: 45000,
    awardMax: 180000,
    eligibility: "eligible",
    deadline: null,
    description: "Foundation supporting community violence intervention and neighborhood safety programs.",
    whyMatches: "Your credible-messenger program fits the foundation's violence-prevention giving.",
    eligibilityConcern: "Foundation favors coalitions with public-agency partnerships.",
    geographicEvidence: "Grants concentrated in urban neighborhoods within your region.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 76, eligibility: 68, geography: 78, awardFit: 70, historical: 72, deadline: 17 },
  },
  {
    id: "irs-18",
    title: "General Operating Support Grants",
    funder: "The Sinclair Foundation",
    source: "irs",
    matchScore: 68,
    confidence: 60,
    effort: 22,
    awardMin: 25000,
    awardMax: 75000,
    eligibility: "eligible",
    deadline: null,
    description: "Foundation known for flexible general operating support to established community nonprofits.",
    whyMatches: "Your organizational profile matches the foundation's general-operating giving pattern.",
    eligibilityConcern: "Foundation typically requires 5+ years of operating history.",
    geographicEvidence: "Grants concentrated among long-established nonprofits in your state.",
    sourceDisclaimer: "Historical giving evidence only. This does not confirm an open application.",
    scores: { mission: 70, eligibility: 78, geography: 72, awardFit: 62, historical: 66, deadline: 20 },
  },
]

export const HEATMAP_COLUMNS = [
  { key: "overall", label: "Overall" },
  { key: "mission", label: "Mission" },
  { key: "eligibility", label: "Eligibility" },
  { key: "geography", label: "Geography" },
  { key: "awardFit", label: "Award fit" },
  { key: "historical", label: "Historical" },
  { key: "deadline", label: "Deadline" },
] as const

export type HeatmapColumnKey = (typeof HEATMAP_COLUMNS)[number]["key"]

export const HEATMAP_COLUMN_HELP: Record<HeatmapColumnKey, string> = {
  overall: "Blended GrantPilot match score across all criteria.",
  mission: "How closely the funder's giving matches your programs and mission.",
  eligibility: "Confidence that your organization meets applicant requirements.",
  geography: "Overlap between the funder's giving area and your service region.",
  awardFit: "Fit between typical award size and your funding need.",
  historical: "Similarity to previously funded organizations or projects.",
  deadline: "Feasibility of the timeline for a competitive application.",
}

export function getScoreValue(grant: Grant, key: HeatmapColumnKey): number {
  if (key === "overall") return grant.matchScore
  return grant.scores[key]
}

export function scoreBucket(value: number): "low" | "mid" | "high" | "top" {
  if (value < 40) return "low"
  if (value < 60) return "mid"
  if (value < 80) return "high"
  return "top"
}

export function formatCurrency(value: number): string {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(1)}M`
  if (value >= 1_000) return `$${Math.round(value / 1_000)}K`
  return `$${value}`
}

export function formatAwardRange(grant: Grant): string {
  if (grant.awardMin == null && grant.awardMax == null) return "Unknown"
  if (grant.singleKnownAward && grant.awardMin != null) return `~${formatCurrency(grant.awardMin)} (single award)`
  if (grant.awardMin != null && grant.awardMax != null) {
    return `${formatCurrency(grant.awardMin)} – ${formatCurrency(grant.awardMax)}`
  }
  if (grant.awardMin != null) return `${formatCurrency(grant.awardMin)}+`
  return "Unknown"
}

export function formatDeadline(grant: Grant): string {
  if (!grant.deadline) return "No confirmed deadline"
  const d = new Date(grant.deadline + "T00:00:00Z")
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" })
}

export function daysUntil(deadline: string): number {
  const d = new Date(deadline + "T00:00:00Z")
  return Math.round((d.getTime() - TODAY.getTime()) / (1000 * 60 * 60 * 24))
}

export type SourceFilter = "all" | "grants.gov" | "irs"
export type EligibilityFilter = "all" | Eligibility
export type AwardFilter = "all" | "under-100k" | "100k-500k" | "over-500k"

export type Filters = {
  source: SourceFilter
  eligibility: EligibilityFilter
  minScore: number
  award: AwardFilter
}

export const DEFAULT_FILTERS: Filters = {
  source: "all",
  eligibility: "all",
  minScore: 0,
  award: "all",
}

function matchesAward(grant: Grant, award: AwardFilter): boolean {
  if (award === "all") return true
  const value = grant.awardMax ?? grant.awardMin
  if (value == null) return false
  if (award === "under-100k") return value < 100_000
  if (award === "100k-500k") return value >= 100_000 && value <= 500_000
  return value > 500_000
}

export function applyFilters(grants: Grant[], filters: Filters): Grant[] {
  return grants.filter((g) => {
    if (filters.source !== "all" && g.source !== filters.source) return false
    if (filters.eligibility !== "all" && g.eligibility !== filters.eligibility) return false
    if (g.matchScore < filters.minScore) return false
    if (!matchesAward(g, filters.award)) return false
    return true
  })
}

export const ELIGIBILITY_LABEL: Record<Eligibility, string> = {
  eligible: "Likely eligible",
  verify: "Verify eligibility",
  ineligible: "Likely ineligible",
}

export const SOURCE_LABEL: Record<GrantSource, string> = {
  "grants.gov": "Grants.gov",
  irs: "IRS 990-PF prospect",
}
