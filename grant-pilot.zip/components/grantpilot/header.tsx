function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="flex flex-col items-end leading-tight">
      <span className="text-sm font-semibold tabular-nums text-foreground">{value}</span>
      <span className="text-[11px] text-muted-foreground">{label}</span>
    </div>
  )
}

export function WorkbenchHeader() {
  return (
    <header className="sticky top-0 z-30 flex h-[72px] items-center justify-between gap-4 border-b border-border bg-card/95 px-4 backdrop-blur md:px-6">
      <div className="leading-tight">
        <h1 className="text-base font-semibold text-foreground">GrantPilot</h1>
      </div>

      <div className="hidden items-center gap-5 sm:flex">
        <Stat value="20" label="opportunities" />
        <div className="h-8 w-px bg-border" />
        <Stat value="2" label="current federal" />
        <Stat value="18" label="historical prospects" />
      </div>
    </header>
  )
}
