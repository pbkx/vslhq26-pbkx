"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  type Grant,
  formatAwardRange,
  formatDeadline,
  formatCurrency,
} from "@/lib/grant-data"
import { SourceBadge, EligibilityBadge, ScoreCircle } from "./badges"
import {
  ExternalLink,
  GitCompareArrows,
  BellPlus,
  Sparkles,
  FileSearch,
  Info,
  MapPin,
  AlertTriangle,
  Lightbulb,
} from "lucide-react"

const SCORE_BARS: { key: keyof Grant["scores"]; label: string }[] = [
  { key: "mission", label: "Mission" },
  { key: "eligibility", label: "Eligibility" },
  { key: "geography", label: "Geography" },
  { key: "awardFit", label: "Award fit" },
  { key: "historical", label: "Historical similarity" },
  { key: "deadline", label: "Deadline" },
]

function barColor(v: number) {
  if (v < 40) return "bg-warning"
  if (v < 60) return "bg-irs"
  if (v < 80) return "bg-primary"
  return "bg-positive"
}

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl border border-border bg-background/60 p-2.5 text-center">
      <p className="text-lg font-semibold tabular-nums text-foreground">{value}</p>
      <p className="text-[11px] text-muted-foreground">{label}</p>
      {sub && <p className="text-[10px] text-muted-foreground/70">{sub}</p>}
    </div>
  )
}

function Section({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof Info
  label: string
  children: React.ReactNode
}) {
  return (
    <div>
      <p className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </p>
      <p className="text-sm leading-relaxed text-foreground/90 text-pretty">{children}</p>
    </div>
  )
}

export function SelectedPanel({
  grant,
  inComparison,
  onToggleComparison,
}: {
  grant: Grant | null
  inComparison: boolean
  onToggleComparison: (id: string) => void
}) {
  if (!grant) {
    return (
      <div className="flex h-full flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card p-8 text-center">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
          <FileSearch className="h-6 w-6" />
        </div>
        <p className="text-sm font-medium text-foreground">No opportunity selected</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Select a grant in any visualization to see its full analysis here.
        </p>
      </div>
    )
  }

  const isIrs = grant.source === "irs"

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card">
      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        {/* header */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <SourceBadge source={grant.source} />
            <EligibilityBadge status={grant.eligibility} />
          </div>
          <ScoreCircle value={grant.matchScore} size={52} />
        </div>

        <div>
          <h2 className="text-base font-semibold leading-snug text-foreground text-pretty">{grant.title}</h2>
          <p className="mt-0.5 text-sm text-muted-foreground">{grant.funder}</p>
        </div>

        {/* metrics */}
        <div className="grid grid-cols-3 gap-2">
          <Metric label="Match score" value={String(grant.matchScore)} />
          <Metric label="Confidence" value={`${grant.confidence}%`} />
          <Metric
            label="Effort"
            value={grant.effort < 40 ? "Low" : grant.effort < 70 ? "Med" : "High"}
          />
        </div>

        {/* award + deadline */}
        <div className="grid grid-cols-2 gap-2">
          <div className="rounded-xl border border-border bg-background/60 p-2.5">
            <p className="text-[11px] text-muted-foreground">Award range</p>
            <p className="text-sm font-semibold text-foreground">{formatAwardRange(grant)}</p>
          </div>
          <div className="rounded-xl border border-border bg-background/60 p-2.5">
            <p className="text-[11px] text-muted-foreground">Deadline</p>
            <p className={cn("text-sm font-semibold", grant.deadline ? "text-foreground" : "text-irs")}>
              {formatDeadline(grant)}
            </p>
          </div>
        </div>

        <div className="h-px bg-border" />

        <Section icon={Info} label="Description">
          {grant.description}
        </Section>
        <Section icon={Lightbulb} label="Why it matches">
          {grant.whyMatches}
        </Section>
        <Section icon={AlertTriangle} label="Main eligibility concern">
          {grant.eligibilityConcern}
        </Section>
        <Section icon={MapPin} label="Geographic evidence">
          {grant.geographicEvidence}
        </Section>

        {/* score bars */}
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            Score breakdown
          </p>
          <div className="space-y-2">
            {SCORE_BARS.map(({ key, label }) => {
              const v = grant.scores[key]
              return (
                <div key={key} className="flex items-center gap-2">
                  <span className="w-32 shrink-0 text-xs text-muted-foreground">{label}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                    <div
                      className={cn("h-full rounded-full transition-all", barColor(v))}
                      style={{ width: `${v}%` }}
                    />
                  </div>
                  <span className="w-6 shrink-0 text-right text-xs font-medium tabular-nums text-foreground">{v}</span>
                </div>
              )
            })}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-muted/40 p-2.5">
          <p className="flex items-start gap-1.5 text-[11px] italic leading-relaxed text-muted-foreground">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            {grant.sourceDisclaimer}
          </p>
        </div>

        {isIrs && (
          <div className="rounded-xl border border-irs/25 bg-irs/10 p-2.5 text-xs font-medium leading-relaxed text-irs">
            Historical giving evidence only. This does not confirm an open application.
          </div>
        )}
      </div>

      {/* actions */}
      <div className="space-y-2 border-t border-border p-4">
        <Button className="w-full rounded-lg">
          {isIrs ? (
            <>
              <FileSearch className="mr-2 h-4 w-4" />
              View IRS evidence
            </>
          ) : (
            <>
              <ExternalLink className="mr-2 h-4 w-4" />
              Open official source
            </>
          )}
        </Button>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            className={cn("rounded-lg bg-card", inComparison && "border-primary bg-accent text-accent-foreground")}
            onClick={() => onToggleComparison(grant.id)}
          >
            <GitCompareArrows className="mr-1.5 h-4 w-4" />
            {inComparison ? "In comparison" : "Add to comparison"}
          </Button>
          <Button variant="outline" className="rounded-lg bg-card">
            <BellPlus className="mr-1.5 h-4 w-4" />
            Create watch
          </Button>
        </div>
        <button
          type="button"
          className="flex w-full items-center justify-center gap-1.5 py-1 text-sm font-medium text-primary transition-colors hover:text-primary/80"
        >
          <Sparkles className="h-4 w-4" />
          Ask Copilot about this grant
        </button>
      </div>
    </div>
  )
}
