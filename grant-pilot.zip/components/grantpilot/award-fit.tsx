"use client"

import { useMemo, useState } from "react"
import { cn } from "@/lib/utils"
import { type Grant, formatCurrency } from "@/lib/grant-data"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const DOMAIN_MAX = 900_000
const TARGET_MIN = 100_000
const TARGET_MAX = 500_000
const TICKS = [0, 200_000, 400_000, 600_000, 800_000]

type Sort = "score" | "award" | "title"

function pct(value: number) {
  return (Math.min(value, DOMAIN_MAX) / DOMAIN_MAX) * 100
}

export function AwardFit({
  grants,
  selectedId,
  onSelect,
}: {
  grants: Grant[]
  selectedId: string | null
  onSelect: (id: string) => void
}) {
  const [sort, setSort] = useState<Sort>("score")

  const rows = useMemo(() => {
    const copy = [...grants]
    if (sort === "score") copy.sort((a, b) => b.matchScore - a.matchScore)
    if (sort === "title") copy.sort((a, b) => a.title.localeCompare(b.title))
    if (sort === "award")
      copy.sort((a, b) => (b.awardMax ?? b.awardMin ?? 0) - (a.awardMax ?? a.awardMin ?? 0))
    return copy
  }, [grants, sort])

  return (
    <div className="flex h-full flex-col">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold text-foreground">Award Fit</h2>
          <p className="text-xs text-muted-foreground">Award ranges vs. your $100K–$500K target band</p>
        </div>
        <Select value={sort} onValueChange={(v) => setSort(v as Sort)}>
          <SelectTrigger className="h-8 w-[150px] rounded-lg bg-card text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="score">Sort: Match score</SelectItem>
            <SelectItem value="award">Sort: Award size</SelectItem>
            <SelectItem value="title">Sort: Title</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex min-h-0 flex-1 overflow-hidden rounded-xl border border-border bg-card">
        <div className="h-full w-full overflow-y-auto">
          {/* header / axis */}
          <div className="sticky top-0 z-10 flex items-center border-b border-border bg-card px-4 py-2">
            <div className="w-[38%] shrink-0 pr-3 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              Opportunity
            </div>
            <div className="relative h-4 flex-1">
              <div
                className="absolute inset-y-0 rounded bg-accent"
                style={{ left: `${pct(TARGET_MIN)}%`, width: `${pct(TARGET_MAX) - pct(TARGET_MIN)}%` }}
              />
              {TICKS.map((t) => (
                <span
                  key={t}
                  className="absolute -translate-x-1/2 text-[10px] text-muted-foreground"
                  style={{ left: `${pct(t)}%` }}
                >
                  {formatCurrency(t)}
                </span>
              ))}
            </div>
          </div>

          <ul>
            {rows.map((g) => {
              const isSel = g.id === selectedId
              const isGov = g.source === "grants.gov"
              const color = isGov ? "hsl(var(--primary))" : "hsl(var(--irs))"
              const unknown = g.awardMin == null && g.awardMax == null
              const single = g.singleKnownAward && g.awardMin != null
              const left = pct(g.awardMin ?? 0)
              const right = pct(g.awardMax ?? g.awardMin ?? 0)
              return (
                <li key={g.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(g.id)}
                    className={cn(
                      "flex w-full items-center px-4 py-2.5 text-left transition-colors hover:bg-muted/60",
                      isSel && "bg-accent",
                    )}
                  >
                    <div className="w-[38%] shrink-0 pr-3">
                      <p className="truncate text-xs font-medium text-foreground">{g.title}</p>
                      <p className="truncate text-[11px] text-muted-foreground">{g.funder}</p>
                    </div>
                    <div className="relative h-6 flex-1">
                      {/* target band guide */}
                      <div
                        className="absolute inset-y-0 rounded bg-accent/60"
                        style={{ left: `${pct(TARGET_MIN)}%`, width: `${pct(TARGET_MAX) - pct(TARGET_MIN)}%` }}
                      />
                      {/* baseline */}
                      <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-border" />
                      {unknown ? (
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full border border-dashed border-muted-foreground/60 bg-card px-2 py-0.5 text-[10px] text-muted-foreground">
                          Unknown
                        </span>
                      ) : single ? (
                        <span
                          className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rotate-45"
                          style={{ left: `${left}%`, background: color }}
                          title="Single known historical award"
                        />
                      ) : (
                        <>
                          <span
                            className="absolute top-1/2 h-2.5 -translate-y-1/2 rounded-full"
                            style={{ left: `${left}%`, width: `${Math.max(right - left, 1)}%`, background: color, opacity: 0.85 }}
                          />
                          <span
                            className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full ring-2 ring-card"
                            style={{ left: `${left}%`, background: color }}
                          />
                          <span
                            className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full ring-2 ring-card"
                            style={{ left: `${right}%`, background: color }}
                          />
                        </>
                      )}
                    </div>
                    <div className="w-14 shrink-0 pl-2 text-right text-xs font-semibold tabular-nums text-foreground">
                      {g.matchScore}
                    </div>
                  </button>
                </li>
              )
            })}
          </ul>
        </div>
      </div>
    </div>
  )
}
