"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Grid2x2, Ruler, Grid3x3, CalendarClock, RotateCcw, X, SlidersHorizontal } from "lucide-react"
import {
  type Filters,
  type AwardFilter,
  type EligibilityFilter,
  type SourceFilter,
  DEFAULT_FILTERS,
} from "@/lib/grant-data"

export type ViewId = "matrix" | "award" | "heatmap" | "deadlines"

const VIEWS: { id: ViewId; label: string; icon: typeof Grid2x2 }[] = [
  { id: "matrix", label: "Match Matrix", icon: Grid2x2 },
  { id: "award", label: "Award Fit", icon: Ruler },
  { id: "heatmap", label: "Score Heatmap", icon: Grid3x3 },
  { id: "deadlines", label: "Deadlines", icon: CalendarClock },
]

const MIN_SCORE_OPTIONS = [0, 60, 70, 80]

const SOURCE_LABELS: Record<SourceFilter, string> = {
  all: "All sources",
  "grants.gov": "Grants.gov",
  irs: "IRS prospects",
}
const ELIGIBILITY_LABELS: Record<EligibilityFilter, string> = {
  all: "All eligibility",
  eligible: "Likely eligible",
  verify: "Needs verification",
  ineligible: "Likely ineligible",
}
const AWARD_LABELS: Record<AwardFilter, string> = {
  all: "Any award size",
  "under-100k": "Under $100K",
  "100k-500k": "$100K – $500K",
  "over-500k": "Over $500K",
}

export function ControlBar({
  view,
  onViewChange,
  filters,
  onFiltersChange,
}: {
  view: ViewId
  onViewChange: (v: ViewId) => void
  filters: Filters
  onFiltersChange: (f: Filters) => void
}) {
  const set = <K extends keyof Filters>(key: K, value: Filters[K]) =>
    onFiltersChange({ ...filters, [key]: value })

  const chips: { key: keyof Filters; label: string }[] = []
  if (filters.source !== "all") chips.push({ key: "source", label: SOURCE_LABELS[filters.source] })
  if (filters.eligibility !== "all") chips.push({ key: "eligibility", label: ELIGIBILITY_LABELS[filters.eligibility] })
  if (filters.minScore > 0) chips.push({ key: "minScore", label: `Score ≥ ${filters.minScore}` })
  if (filters.award !== "all") chips.push({ key: "award", label: AWARD_LABELS[filters.award] })

  const hasFilters = chips.length > 0

  return (
    <div className="sticky top-[72px] z-20 border-b border-border bg-background/90 backdrop-blur">
      <div className="flex items-center gap-3 overflow-x-auto px-4 py-3 no-scrollbar md:px-6">
        {/* Segmented view selector */}
        <div className="flex shrink-0 items-center gap-1 rounded-xl border border-border bg-card p-1 shadow-sm">
          {VIEWS.map(({ id, label, icon: Icon }) => {
            const active = view === id
            return (
              <button
                key={id}
                type="button"
                onClick={() => onViewChange(id)}
                aria-pressed={active}
                className={cn(
                  "inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            )
          })}
        </div>

        <div className="hidden h-6 w-px shrink-0 bg-border lg:block" />

        {/* Filters */}
        <div className="flex shrink-0 items-center gap-2">
          <SlidersHorizontal className="hidden h-4 w-4 text-muted-foreground lg:block" />
          <Select value={filters.source} onValueChange={(v) => set("source", v as SourceFilter)}>
            <SelectTrigger className="h-9 w-[150px] rounded-lg bg-card text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(SOURCE_LABELS) as SourceFilter[]).map((k) => (
                <SelectItem key={k} value={k}>
                  {SOURCE_LABELS[k]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filters.eligibility} onValueChange={(v) => set("eligibility", v as EligibilityFilter)}>
            <SelectTrigger className="h-9 w-[168px] rounded-lg bg-card text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(ELIGIBILITY_LABELS) as EligibilityFilter[]).map((k) => (
                <SelectItem key={k} value={k}>
                  {ELIGIBILITY_LABELS[k]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={String(filters.minScore)} onValueChange={(v) => set("minScore", Number(v))}>
            <SelectTrigger className="h-9 w-[130px] rounded-lg bg-card text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MIN_SCORE_OPTIONS.map((s) => (
                <SelectItem key={s} value={String(s)}>
                  {s === 0 ? "Any score" : `Score ≥ ${s}`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filters.award} onValueChange={(v) => set("award", v as AwardFilter)}>
            <SelectTrigger className="h-9 w-[150px] rounded-lg bg-card text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(AWARD_LABELS) as AwardFilter[]).map((k) => (
                <SelectItem key={k} value={k}>
                  {AWARD_LABELS[k]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            variant="ghost"
            size="sm"
            className="h-9 shrink-0 rounded-lg text-muted-foreground hover:text-foreground"
            onClick={() => onFiltersChange(DEFAULT_FILTERS)}
            disabled={!hasFilters}
          >
            <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
            Reset
          </Button>
        </div>
      </div>

      {hasFilters && (
        <div className="flex flex-wrap items-center gap-2 px-4 pb-3 md:px-6">
          <span className="text-xs text-muted-foreground">Active filters:</span>
          {chips.map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={() => set(chip.key, DEFAULT_FILTERS[chip.key] as never)}
              className="inline-flex items-center gap-1 rounded-full border border-border bg-card py-1 pl-2.5 pr-1.5 text-xs font-medium text-foreground transition-colors hover:bg-muted"
            >
              {chip.label}
              <X className="h-3 w-3 text-muted-foreground" />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
