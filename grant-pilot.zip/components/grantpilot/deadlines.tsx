"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { type Grant, daysUntil, formatDeadline, formatAwardRange } from "@/lib/grant-data"
import { GrantTooltip } from "./chart-tooltip"

const HORIZON = 365
const REF_LINES = [30, 60, 90]
const MONTH_TICKS = [0, 60, 120, 180, 240, 300, 360]

function scoreColor(score: number) {
  if (score < 40) return "hsl(var(--warning))"
  if (score < 60) return "hsl(var(--irs))"
  if (score < 80) return "hsl(var(--primary))"
  return "hsl(var(--positive))"
}

function markerSize(grant: Grant) {
  const value = grant.awardMax ?? grant.awardMin ?? 20000
  return 14 + Math.min(1, value / 800000) * 16
}

function monthLabel(days: number) {
  const d = new Date("2026-07-28T00:00:00Z")
  d.setUTCDate(d.getUTCDate() + days)
  return d.toLocaleDateString("en-US", { month: "short", timeZone: "UTC" })
}

export function Deadlines({
  grants,
  selectedId,
  onSelect,
}: {
  grants: Grant[]
  selectedId: string | null
  onSelect: (id: string) => void
}) {
  const [hoverId, setHoverId] = useState<string | null>(null)

  const federal = grants
    .filter((g) => g.source === "grants.gov" && g.deadline)
    .map((g) => ({ g, days: daysUntil(g.deadline as string) }))
    .filter((x) => x.days >= 0 && x.days <= HORIZON)
  const historical = grants.filter((g) => g.source === "irs")
  const hovered = federal.find((x) => x.g.id === hoverId)?.g

  const px = (days: number) => 4 + (days / HORIZON) * 92

  return (
    <div className="flex h-full flex-col">
      <div className="mb-3">
        <h2 className="text-sm font-semibold text-foreground">Deadlines</h2>
        <p className="text-xs text-muted-foreground">
          Current federal opportunities over the next 12 months · marker size = award, color = match
        </p>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto rounded-xl border border-border bg-card p-4">
        {/* Open opportunities lane */}
        <p className="mb-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Open federal opportunities
        </p>
        <div className="relative h-40 rounded-lg border border-border bg-background/60">
          {/* month gridlines */}
          {MONTH_TICKS.map((d) => (
            <div key={d} className="absolute inset-y-0" style={{ left: `${px(d)}%` }}>
              <div className="h-full w-px bg-border/70" />
              <span className="absolute -bottom-5 -translate-x-1/2 text-[10px] text-muted-foreground">
                {monthLabel(d)}
              </span>
            </div>
          ))}
          {/* reference lines */}
          {REF_LINES.map((d) => (
            <div key={d} className="absolute inset-y-0" style={{ left: `${px(d)}%` }}>
              <div className="h-full w-px border-l border-dashed border-primary/40" />
              <span className="absolute top-1 left-1 text-[10px] font-medium text-primary/70">{d}d</span>
            </div>
          ))}
          {/* baseline */}
          <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-border" />

          {federal.map(({ g, days }) => {
            const size = markerSize(g)
            const isSel = g.id === selectedId
            return (
              <button
                key={g.id}
                type="button"
                onClick={() => onSelect(g.id)}
                onMouseEnter={() => setHoverId(g.id)}
                onMouseLeave={() => setHoverId((c) => (c === g.id ? null : c))}
                aria-label={`${g.title}, due in ${days} days`}
                className={cn(
                  "absolute top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full ring-2 ring-card transition-all focus:outline-none focus-visible:ring-primary",
                  isSel && "z-20 scale-110",
                )}
                style={{ left: `${px(days)}%`, width: size, height: size, background: scoreColor(g.matchScore) }}
              >
                {isSel && <span className="absolute inset-0 rounded-full ring-2 ring-offset-2 ring-offset-card ring-primary" />}
              </button>
            )
          })}

          {hovered && (
            <GrantTooltip
              grant={hovered}
              x={px(daysUntil(hovered.deadline as string))}
              y={50}
            />
          )}
        </div>
        <div className="mt-7" />

        {/* Historical lane */}
        <div className="mb-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-irs" />
            <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              Historical prospects
            </p>
          </div>
          <span className="rounded-full border border-border bg-muted/50 px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
            No confirmed deadline
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 lg:grid-cols-3">
          {historical.map((g) => {
            const isSel = g.id === selectedId
            return (
              <button
                key={g.id}
                type="button"
                onClick={() => onSelect(g.id)}
                title={g.title}
                className={cn(
                  "flex items-center justify-between gap-3 rounded-lg border px-3 py-2 text-left transition-colors",
                  isSel
                    ? "border-irs bg-irs/10"
                    : "border-border bg-background/60 hover:border-irs/40 hover:bg-irs/5",
                )}
              >
                <span className="min-w-0">
                  <span className="block truncate text-xs font-medium text-foreground">{g.funder}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">{formatAwardRange(g)}</span>
                </span>
                <span className="shrink-0 text-xs font-semibold tabular-nums text-muted-foreground">
                  {g.matchScore}
                </span>
              </button>
            )
          })}
          {historical.length === 0 && (
            <p className="col-span-full text-xs text-muted-foreground">
              No historical prospects match the current filters.
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
