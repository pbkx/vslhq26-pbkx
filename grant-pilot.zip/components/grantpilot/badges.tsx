import { cn } from "@/lib/utils"
import { CheckCircle2, HelpCircle, XCircle, Landmark, Building2 } from "lucide-react"
import type { Eligibility, GrantSource } from "@/lib/grant-data"

export function SourceBadge({ source, className }: { source: GrantSource; className?: string }) {
  const isGov = source === "grants.gov"
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
        isGov
          ? "border-primary/20 bg-accent text-accent-foreground"
          : "border-irs/25 bg-irs/10 text-irs",
        className,
      )}
    >
      {isGov ? <Landmark className="h-3.5 w-3.5" /> : <Building2 className="h-3.5 w-3.5" />}
      {isGov ? "Grants.gov" : "IRS prospect"}
    </span>
  )
}

export function EligibilityBadge({ status, className }: { status: Eligibility; className?: string }) {
  const map = {
    eligible: {
      icon: CheckCircle2,
      label: "Likely eligible",
      cls: "border-positive/25 bg-positive/10 text-positive",
    },
    verify: {
      icon: HelpCircle,
      label: "Verify eligibility",
      cls: "border-irs/25 bg-irs/10 text-irs",
    },
    ineligible: {
      icon: XCircle,
      label: "Likely ineligible",
      cls: "border-warning/25 bg-warning/10 text-warning",
    },
  } as const
  const { icon: Icon, label, cls } = map[status]
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
        cls,
        className,
      )}
    >
      <Icon className="h-3.5 w-3.5" />
      {label}
    </span>
  )
}

export function scoreTextClass(value: number): string {
  if (value < 40) return "text-warning"
  if (value < 60) return "text-irs"
  if (value < 80) return "text-primary"
  return "text-positive"
}

export function ScoreCircle({
  value,
  size = 44,
  className,
}: {
  value: number
  size?: number
  className?: string
}) {
  const stroke = 4
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const offset = c - (value / 100) * c
  const color =
    value < 40 ? "hsl(var(--warning))" : value < 60 ? "hsl(var(--irs))" : value < 80 ? "hsl(var(--primary))" : "hsl(var(--positive))"
  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="hsl(var(--muted))" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-500"
        />
      </svg>
      <span className="absolute text-sm font-semibold tabular-nums" style={{ color }}>
        {value}
      </span>
    </div>
  )
}
