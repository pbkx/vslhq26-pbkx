"use client"

import { cn } from "@/lib/utils"
import { type Grant, formatAwardRange, formatDeadline, ELIGIBILITY_LABEL, SOURCE_LABEL } from "@/lib/grant-data"

export function GrantTooltip({
  grant,
  x,
  y,
  note,
}: {
  grant: Grant
  /** left percentage within the container */
  x: number
  /** top percentage within the container */
  y: number
  note?: string
}) {
  return (
    <div
      className="pointer-events-none absolute z-40 w-60 -translate-x-1/2 -translate-y-[calc(100%+12px)] rounded-xl border border-border bg-popover p-3 text-popover-foreground shadow-lg"
      style={{ left: `${x}%`, top: `${y}%` }}
    >
      <p className="text-sm font-semibold leading-snug text-pretty">{grant.title}</p>
      <p className="mt-0.5 text-xs text-muted-foreground">{grant.funder}</p>
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
        <Tip label="Source" value={SOURCE_LABEL[grant.source]} />
        <Tip label="Match" value={`${grant.matchScore}/100`} />
        <Tip label="Award" value={formatAwardRange(grant)} />
        <Tip label="Deadline" value={formatDeadline(grant)} />
      </dl>
      <p
        className={cn(
          "mt-2 text-xs font-medium",
          grant.eligibility === "eligible"
            ? "text-positive"
            : grant.eligibility === "verify"
              ? "text-irs"
              : "text-warning",
        )}
      >
        {ELIGIBILITY_LABEL[grant.eligibility]}
      </p>
      {note && <p className="mt-1 text-[11px] italic text-muted-foreground">{note}</p>}
    </div>
  )
}

function Tip({ label, value }: { label: string; value: string }) {
  return (
    <div className="leading-tight">
      <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="font-medium text-foreground">{value}</dd>
    </div>
  )
}
