"use client"

import { useMemo, useState } from "react"
import { cn } from "@/lib/utils"
import { Checkbox } from "@/components/ui/checkbox"
import { type Grant, formatAwardRange, formatDeadline } from "@/lib/grant-data"
import { SourceBadge, EligibilityBadge } from "./badges"
import { ChevronDown } from "lucide-react"

export function RankedStrip({
  grants,
  selectedId,
  onSelect,
  comparison,
  onToggleComparison,
}: {
  grants: Grant[]
  selectedId: string | null
  onSelect: (id: string) => void
  comparison: Set<string>
  onToggleComparison: (id: string) => void
}) {
  const [open, setOpen] = useState(true)
  const ranked = useMemo(() => [...grants].sort((a, b) => b.matchScore - a.matchScore), [grants])

  return (
    <section className="rounded-2xl border border-border bg-card">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-2 px-4 py-3 text-left"
      >
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold text-foreground">Ranked opportunities</h2>
          <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
            {ranked.length}
          </span>
          {comparison.size > 0 && (
            <span className="rounded-full bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground">
              {comparison.size} in comparison
            </span>
          )}
        </div>
        <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div className="overflow-x-auto border-t border-border">
          <div className="min-w-[720px]">
            {/* header row */}
            <div className="flex items-center gap-3 border-b border-border bg-muted/40 px-4 py-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              <span className="w-8 text-center">#</span>
              <span className="w-10 text-center">Score</span>
              <span className="flex-1">Opportunity</span>
              <span className="w-32">Source</span>
              <span className="w-28">Award</span>
              <span className="w-24">Deadline</span>
              <span className="w-32">Eligibility</span>
              <span className="w-16 text-center">Compare</span>
            </div>
            <ul>
              {ranked.map((g, i) => {
                const isSel = g.id === selectedId
                return (
                  <li key={g.id}>
                    <div
                      role="button"
                      tabIndex={0}
                      onClick={() => onSelect(g.id)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault()
                          onSelect(g.id)
                        }
                      }}
                      className={cn(
                        "flex cursor-pointer items-center gap-3 border-b border-border px-4 py-2.5 text-sm transition-colors last:border-0 hover:bg-muted/50",
                        isSel && "bg-accent hover:bg-accent",
                      )}
                    >
                      <span className="w-8 text-center text-xs font-semibold text-muted-foreground tabular-nums">
                        {i + 1}
                      </span>
                      <span className="w-10 text-center text-sm font-semibold tabular-nums text-foreground">
                        {g.matchScore}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="truncate text-xs font-medium text-foreground">{g.title}</p>
                        <p className="truncate text-[11px] text-muted-foreground">{g.funder}</p>
                      </div>
                      <span className="w-32">
                        <SourceBadge source={g.source} />
                      </span>
                      <span className="w-28 text-xs tabular-nums text-foreground">{formatAwardRange(g)}</span>
                      <span
                        className={cn(
                          "w-24 text-xs",
                          g.deadline ? "text-foreground" : "text-muted-foreground",
                        )}
                      >
                        {formatDeadline(g)}
                      </span>
                      <span className="w-32">
                        <EligibilityBadge status={g.eligibility} />
                      </span>
                      <span
                        className="flex w-16 justify-center"
                        onClick={(e) => e.stopPropagation()}
                        onKeyDown={(e) => e.stopPropagation()}
                      >
                        <Checkbox
                          checked={comparison.has(g.id)}
                          onCheckedChange={() => onToggleComparison(g.id)}
                          aria-label={`Add ${g.title} to comparison`}
                        />
                      </span>
                    </div>
                  </li>
                )
              })}
              {ranked.length === 0 && (
                <li className="px-4 py-6 text-center text-sm text-muted-foreground">
                  No opportunities match the current filters.
                </li>
              )}
            </ul>
          </div>
        </div>
      )}
    </section>
  )
}
