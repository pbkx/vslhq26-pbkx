"use client"

import { useMemo, useState } from "react"
import { cn } from "@/lib/utils"
import {
  type Grant,
  type HeatmapColumnKey,
  HEATMAP_COLUMNS,
  HEATMAP_COLUMN_HELP,
  getScoreValue,
  scoreBucket,
} from "@/lib/grant-data"
import { ArrowDown } from "lucide-react"
import { SourceBadge } from "./badges"

function cellStyle(value: number): { background: string; color: string } {
  const bucket = scoreBucket(value)
  const hueVar =
    bucket === "low"
      ? "--score-low"
      : bucket === "mid"
        ? "--score-mid"
        : bucket === "high"
          ? "--score-high"
          : "--score-top"
  const alpha = 0.22 + (value / 100) * 0.68
  return {
    background: `hsl(var(${hueVar}) / ${alpha})`,
    color: alpha > 0.6 ? "hsl(0 0% 100%)" : "hsl(var(--foreground))",
  }
}

export function ScoreHeatmap({
  grants,
  selectedId,
  onSelect,
}: {
  grants: Grant[]
  selectedId: string | null
  onSelect: (id: string) => void
}) {
  const [sortKey, setSortKey] = useState<HeatmapColumnKey>("overall")
  const [tooltip, setTooltip] = useState<{ key: HeatmapColumnKey; grant: Grant } | null>(null)

  const rows = useMemo(
    () => [...grants].sort((a, b) => getScoreValue(b, sortKey) - getScoreValue(a, sortKey)),
    [grants, sortKey],
  )

  return (
    <div className="flex h-full flex-col">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold text-foreground">Score Heatmap</h2>
          <p className="text-xs text-muted-foreground">Click a heading to sort · click a cell for detail</p>
        </div>
        <Scale />
      </div>

      <div className="flex min-h-0 flex-1 overflow-hidden rounded-xl border border-border bg-card">
        <div className="h-full w-full overflow-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="sticky top-0 z-20">
                <th className="sticky left-0 z-30 min-w-[200px] border-b border-r border-border bg-card px-3 py-2 text-left text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                  Opportunity
                </th>
                {HEATMAP_COLUMNS.map((col) => {
                  const active = sortKey === col.key
                  return (
                    <th key={col.key} className="border-b border-border bg-card p-0">
                      <button
                        type="button"
                        onClick={() => setSortKey(col.key)}
                        className={cn(
                          "flex w-full min-w-[74px] items-center justify-center gap-1 px-2 py-2 text-[11px] font-medium transition-colors hover:bg-muted",
                          active ? "text-primary" : "text-muted-foreground",
                        )}
                      >
                        {col.label}
                        {active && <ArrowDown className="h-3 w-3" />}
                      </button>
                    </th>
                  )
                })}
              </tr>
            </thead>
            <tbody>
              {rows.map((g) => {
                const isSel = g.id === selectedId
                return (
                  <tr key={g.id} className={cn("group", isSel && "outline outline-2 -outline-offset-2 outline-primary")}>
                    <th
                      scope="row"
                      className={cn(
                        "sticky left-0 z-10 min-w-[200px] max-w-[200px] border-b border-r border-border px-3 py-2 text-left",
                        isSel ? "bg-accent" : "bg-card group-hover:bg-muted/50",
                      )}
                    >
                      <button type="button" onClick={() => onSelect(g.id)} className="block w-full text-left">
                        <span className="block truncate text-xs font-medium text-foreground">{g.title}</span>
                        <span className="mt-1 inline-block">
                          <SourceBadge source={g.source} />
                        </span>
                      </button>
                    </th>
                    {HEATMAP_COLUMNS.map((col) => {
                      const value = getScoreValue(g, col.key)
                      const isTipCell = tooltip?.grant.id === g.id && tooltip?.key === col.key
                      return (
                        <td key={col.key} className="relative border-b border-border p-1 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              onSelect(g.id)
                              setTooltip({ key: col.key, grant: g })
                            }}
                            onMouseEnter={() => setTooltip({ key: col.key, grant: g })}
                            onMouseLeave={() => setTooltip((c) => (c?.grant.id === g.id && c.key === col.key ? null : c))}
                            className="flex h-9 w-full items-center justify-center rounded-md text-xs font-semibold tabular-nums transition-transform hover:scale-[1.06] focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            style={cellStyle(value)}
                          >
                            {value}
                          </button>
                          {isTipCell && (
                            <div className="pointer-events-none absolute bottom-[calc(100%+6px)] left-1/2 z-40 w-52 -translate-x-1/2 rounded-lg border border-border bg-popover p-2.5 text-left text-popover-foreground shadow-lg">
                              <p className="text-xs font-semibold">{col.label}</p>
                              <p className="mt-0.5 text-[11px] text-muted-foreground">{HEATMAP_COLUMN_HELP[col.key]}</p>
                            </div>
                          )}
                        </td>
                      )
                    })}
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function Scale() {
  const items = [
    { label: "0–39", cls: "bg-warning" },
    { label: "40–59", cls: "bg-irs" },
    { label: "60–79", cls: "bg-primary" },
    { label: "80–100", cls: "bg-positive" },
  ]
  return (
    <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
      {items.map((i) => (
        <span key={i.label} className="inline-flex items-center gap-1">
          <span className={cn("h-3 w-3 rounded-sm", i.cls)} />
          {i.label}
        </span>
      ))}
    </div>
  )
}
