"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { type Grant } from "@/lib/grant-data"
import { GrantTooltip } from "./chart-tooltip"

// plot insets as percentages of the container
const PAD = { top: 6, bottom: 12, left: 8, right: 5 }

function awardRadius(grant: Grant): number {
  const value = grant.awardMax ?? grant.awardMin ?? 20000
  const capped = Math.min(value, 800000)
  // logarithmic-ish scale
  const t = Math.log10(capped / 10000) / Math.log10(80)
  return 7 + Math.max(0, Math.min(1, t)) * 16
}

export function MatchMatrix({
  grants,
  selectedId,
  onSelect,
}: {
  grants: Grant[]
  selectedId: string | null
  onSelect: (id: string) => void
}) {
  const [hoverId, setHoverId] = useState<string | null>(null)
  const hovered = grants.find((g) => g.id === hoverId)

  const plotW = 100 - PAD.left - PAD.right
  const plotH = 100 - PAD.top - PAD.bottom

  const px = (effort: number) => PAD.left + (effort / 100) * plotW
  const py = (score: number) => PAD.top + (1 - score / 100) * plotH

  const quadrants = [
    { label: "Best bets", x: PAD.left + plotW * 0.02, y: PAD.top + plotH * 0.06, align: "left" },
    { label: "Strategic investments", x: PAD.left + plotW * 0.98, y: PAD.top + plotH * 0.06, align: "right" },
    { label: "Quick research", x: PAD.left + plotW * 0.02, y: PAD.top + plotH * 0.94, align: "left" },
    { label: "Low priority", x: PAD.left + plotW * 0.98, y: PAD.top + plotH * 0.94, align: "right" },
  ] as const

  return (
    <div className="flex h-full flex-col">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold text-foreground">Match Matrix</h2>
          <p className="text-xs text-muted-foreground">Match score vs. application effort · bubble size = award amount</p>
        </div>
        <Legend />
      </div>

      <div className="relative min-h-[420px] flex-1 rounded-xl border border-border bg-card">
        {/* gridlines + quadrant split */}
        <div className="absolute inset-0" style={{ padding: `${PAD.top}% ${PAD.right}% ${PAD.bottom}% ${PAD.left}%` }}>
          <div className="relative h-full w-full">
            <div className="absolute left-1/2 top-0 h-full w-px bg-border" />
            <div className="absolute left-0 top-1/2 h-px w-full bg-border" />
          </div>
        </div>

        {/* quadrant labels */}
        {quadrants.map((q) => (
          <span
            key={q.label}
            className="pointer-events-none absolute text-[11px] font-medium uppercase tracking-wide text-muted-foreground/70"
            style={{
              left: `${q.x}%`,
              top: `${q.y}%`,
              transform: `translate(${q.align === "right" ? "-100%" : "0"}, -50%)`,
            }}
          >
            {q.label}
          </span>
        ))}

        {/* axis labels */}
        <span className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 text-[11px] text-muted-foreground">
          Application effort: Low → High
        </span>
        <span className="pointer-events-none absolute left-2 top-1/2 -rotate-90 text-[11px] text-muted-foreground">
          Match score
        </span>

        {/* bubbles */}
        {grants.map((g) => {
          const r = awardRadius(g)
          const isSel = g.id === selectedId
          const isHover = g.id === hoverId
          const isGov = g.source === "grants.gov"
          const ineligible = g.eligibility === "ineligible"
          return (
            <button
              key={g.id}
              type="button"
              onClick={() => onSelect(g.id)}
              onMouseEnter={() => setHoverId(g.id)}
              onMouseLeave={() => setHoverId((c) => (c === g.id ? null : c))}
              onFocus={() => setHoverId(g.id)}
              onBlur={() => setHoverId((c) => (c === g.id ? null : c))}
              aria-label={`${g.title}, match ${g.matchScore}`}
              className={cn(
                "absolute -translate-x-1/2 -translate-y-1/2 rounded-full transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                isSel ? "z-20" : isHover ? "z-10" : "z-0",
              )}
              style={{ left: `${px(g.effort)}%`, top: `${py(g.matchScore)}%`, width: r * 2, height: r * 2 }}
            >
              <span
                className={cn(
                  "block h-full w-full rounded-full transition-all",
                  isGov ? "bg-primary/70" : "bg-irs/70",
                  ineligible && "opacity-40 grayscale",
                  isSel && "ring-2 ring-offset-2 ring-offset-card",
                  isSel && (isGov ? "ring-primary" : "ring-irs"),
                )}
                style={{
                  border: `2px ${g.eligibility === "verify" ? "dashed" : "solid"} ${
                    isGov ? "hsl(var(--primary))" : "hsl(var(--irs))"
                  }`,
                }}
              />
              {ineligible && (
                <span className="absolute inset-0 flex items-center justify-center text-warning">
                  <span className="h-[2px] w-[70%] rotate-45 rounded bg-warning" />
                </span>
              )}
            </button>
          )
        })}

        {hovered && (
          <GrantTooltip
            grant={hovered}
            x={px(hovered.effort)}
            y={py(hovered.matchScore)}
            note={hovered.source === "irs" ? "Historical prospect — not a confirmed open opportunity" : undefined}
          />
        )}
      </div>
    </div>
  )
}

function Legend() {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-muted-foreground">
      <span className="inline-flex items-center gap-1.5">
        <span className="h-3 w-3 rounded-full bg-primary/70 ring-1 ring-primary" /> Grants.gov
      </span>
      <span className="inline-flex items-center gap-1.5">
        <span className="h-3 w-3 rounded-full bg-irs/70 ring-1 ring-irs" /> IRS prospect
      </span>
      <span className="inline-flex items-center gap-1.5">
        <span className="h-3 w-3 rounded-full border-2 border-dashed border-muted-foreground" /> Verify
      </span>
    </div>
  )
}
